def update():
	paths = ['[default]HTTP/Outside Temp degC']
	values = ['']
	
	url = 'https://api.openweathermap.org/data/2.5/onecall'
	apiKey = 'c775efd23208322b9e18bbfa3f5fc398'
	lat = 36.3729
	lon = -94.2088
	units = 'metric'
	payload = {'appid': apiKey, 'lat': lat, 'lon': lon, 'units': units}
	
	client = system.net.httpClient()
	r = client.get(url, params = payload)
	data = r.json
	
	values[0] = data['current']['temp']
	system.tag.writeBlocking(paths, values)
	