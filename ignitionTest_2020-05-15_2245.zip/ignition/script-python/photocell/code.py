def update():
	url = 'https://io.adafruit.com/api/v2/Freeno83/feeds/photocell/data/last'
	aioKey = 'aio_yUtI57j00fgjTxZxWBLx5EsnVPfe'

	paths = ['[default]HTTP/Photocell']
	values = ['']
	
	client = system.net.httpClient()
	r = client.get(url, {'x-aio-key': aioKey})
	data = r.json
	print 'Photocell value {}'.format(data['value'])

	values[0] = data['value']
	quality = system.tag.writeBlocking(paths, values)
	print '{} write quality: {}'.format(paths, quality)